INSTRUKSI PENGGUNAAN
====================

File-file HTML ini adalah generator PDF menggunakan pdf-lib.
Untuk menghasilkan PDF:

1. Buka file HTML di browser (Chrome/Firefox/Edge)
2. PDF akan otomatis di-generate dan terbuka di tab baru
3. Gunakan Ctrl+P (Windows) atau Cmd+P (Mac) untuk print/save as PDF
4. ATAU tunggu hingga jendela print otomatis muncul

Catatan: Pastikan koneksi internet aktif saat membuka file HTML
karena membutuhkan library pdf-lib dari CDN.

Generated: 2025-12-08 07:51:10
